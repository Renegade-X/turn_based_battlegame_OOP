package ooplab02;

// Item Class - Represents items a player can use

public class Item {
    private String name;
    private int type;

    public Item(String name, int type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public int getType() {
        return type;
    }
}
